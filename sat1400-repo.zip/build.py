#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
src/template.html のプレースホルダに src/data/*.json を差し込み、
docs/index.html を生成する。

なぜ分けるのか:
  完成した HTML は 330KB あり、うち大半が単語データ。
  1 ファイルのまま編集すると差分が読めず、変更履歴も追えない。
  データと表示を分けておけば、語の追加もレイアウト修正も個別に行える。

使い方:
  python3 build.py            # docs/index.html を生成
  python3 build.py --check    # 生成せずに検査だけ行う
"""
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(ROOT, "src")
DATA = os.path.join(SRC, "data")
OUT = os.path.join(ROOT, "docs", "index.html")

# プレースホルダ名 -> データファイル
SLOTS = {
    "__DATA__":     ("sat1400_deck.json", lambda d: d["words"]),
    "__TIERS__":    ("sat1400_deck.json", lambda d: d["tiers"]),
    "__DRILLS__":   ("drills.json",       lambda d: d),
    "__CLUSTERS__": ("clusters.json",     lambda d: d),
    "__TRANS__":    ("trans.json",        lambda d: d),
    "__MORPH__":    ("morph.json",        lambda d: d),
}


def load(name):
    with open(os.path.join(DATA, name), encoding="utf-8") as f:
        return json.load(f)


def build():
    with open(os.path.join(SRC, "template.html"), encoding="utf-8") as f:
        html = f.read()

    cache = {}
    for slot, (fname, pick) in SLOTS.items():
        if fname not in cache:
            cache[fname] = load(fname)
        blob = json.dumps(pick(cache[fname]), ensure_ascii=False, separators=(",", ":"))
        # </script> が含まれると HTML が壊れるため事前に検査する
        if "</script" in blob.lower():
            raise SystemExit(f"{slot} に </script> が含まれています")
        html = html.replace(slot, blob)

    left = re.findall(r"__[A-Z]+__", html)
    if left:
        raise SystemExit(f"未置換のプレースホルダ: {sorted(set(left))}")

    # 単体動作の保証。
    # 相対参照(./manifest.json など)は同じ場所に置くだけで、無くても本体は動くため許容する。
    # 禁じるのは外部サーバーへの依存だけ。
    for pat, label in [
        (r"https?://[^\s\"'<>]+", "外部 URL"),
        (r"<script[^>]+src=\s*[\"']https?:", "外部スクリプト"),
        (r"<link[^>]+href=\s*[\"']https?:", "外部スタイル"),
        (r"\bfetch\s*\(", "fetch"),
        (r"XMLHttpRequest", "XHR"),
        (r"@import", "外部CSS取込"),
    ]:
        hits = re.findall(pat, html)
        if hits:
            raise SystemExit(f"{label} が含まれています: {hits[:3]}")

    # 本体に単語データが埋め込まれていること(分割されていないこと)を確認する
    if "var DATA" not in html or len(html) < 200000:
        raise SystemExit("単語データが本体に埋め込まれていません")

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        f.write(html)
    return html


def check(html):
    deck = load("sat1400_deck.json")
    words = [w[0] for w in deck["words"]]
    problems = []

    if len(words) != len(set(words)):
        problems.append("デッキに重複した語があります")

    clusters = load("clusters.json")
    members = [m[0] for c in clusters for m in c[2]]
    if len(members) != len(set(members)):
        problems.append("意味グループに重複した語があります")
    for i, c in enumerate(clusters):
        a = c[3]
        if a is not None and (not (0 <= a < len(clusters)) or clusters[a][3] != i):
            problems.append(f"対義グループのリンクが片方向です: {i}")

    trans = load("trans.json")
    unknown = [k for k in trans if k not in set(words)]
    if unknown:
        problems.append(f"デッキに無い語の和訳があります: {unknown[:5]}")

    print(f"語数 {len(words)} / 意味グループ {len(clusters)} 群 {len(members)} 語 / 和訳 {len(trans)} 語")
    print(f"生成サイズ {len(html.encode('utf-8')) / 1024:.0f} KB")
    if problems:
        for p in problems:
            print("要修正:", p)
        return 1
    print("検査: 問題なし")
    return 0


if __name__ == "__main__":
    html = build()
    code = check(html)
    if "--check" in sys.argv:
        os.remove(OUT)
    else:
        print(f"生成: {OUT}")
    sys.exit(code)
